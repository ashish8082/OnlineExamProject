<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
    <link rel="stylesheet" type="text/css" href="style1.css">
</head>
<body>

<div id="header">
    <?php include 'header.php'; ?>
</div>


<div style="margin-top: 3%;" align="center">
    <a href><img src="aboutbanner.jpg" height="110px" width=500"> </a>
</div>

<br/><br/><br/><br/>
<center><h4 style="font-family:Comic Sans MS;"> This Online Examination is for the people who aspire to score high marks in general competitive exams<br>
        like Java,PHP,C++,CSS Exams, etc., at free of cost. This site will be your practice ground. You can write<br>
        various model exams available here and evaluate yourself based on your score. Questions are collected from<br>
        various competitive exams and presented as online tests here for your self training. you need to register for<br>
        write the exam click here for registration.</h4></center>
<br/><br/><br/><br/>


<div>
    <?php include 'footer.php'; ?>
</div>

</body>
</html>