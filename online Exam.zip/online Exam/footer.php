
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style type="text/css">
div #fixedfooter {
	position:relative;
	bottom:0px;
	left:0px;
	width:100%;
	color:white;
	background-color:black;
	padding:6px;
	font-family:Comic Sans MS;
	float:inherit;
}
</style>

</head>

<body>
	<div id="fixedfooter" align="center">
		&copy; All rights reserved
	</div>
</body>
</html>